<?php
error_reporting(NULL);
$TAB = 'CSF';

// Main include
include($_SERVER['DOCUMENT_ROOT']."/inc/main.php");

// Check user
if ($_SESSION['user'] != 'admin') {
    header("Location: /list/user");
    exit;
}

// Data
if(isset($_POST['action']))
	$env=http_build_query($_POST);
if(isset($_GET['action']))
	$env=http_build_query($_GET);
exec (VESTA_CMD . "v-csf \"$env\"", $output, $return_var);
$data = implode("\n", $output);
// Render page
render_page($user, $TAB, 'list_csf');

// Back uri
$_SESSION['back'] = $_SERVER['REQUEST_URI'];

